<?php
/**
 * Russian permissions Lexicon Entries for AjaxLogin
 *
 * @package AjaxLogin
 * @subpackage lexicon
 */
$_lang['ajaxlogin_save'] = 'Permission for save/update data.';