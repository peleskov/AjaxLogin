<?php
/**
 * English permissions Lexicon Entries for AjaxLogin
 *
 * @package AjaxLogin
 * @subpackage lexicon
 */
$_lang['ajaxlogin_save'] = 'Разрешает создание/изменение данных.';