<?php

$_lang['area_ajaxlogin_main'] = 'Main';

$_lang['setting_ajaxlogin_some_setting'] = 'Some setting';
$_lang['setting_ajaxlogin_some_setting_desc'] = 'This is description for some setting';